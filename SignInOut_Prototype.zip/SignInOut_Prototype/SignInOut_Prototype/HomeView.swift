//
//  .swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/07.
//

/*
 사이즈 왜 안맞음 피그마랑 으아아
import SwiftUI

struct HomeView : View{
    var body: some View{
        Text("생자대 생활 정보 톡")//Roboto, 18, Drop shadow, W146 H21
            .position (x:107, y:58)
        Text("로그인")//Roboto, 15
            .position (x:159, y:90)
        Text("아이디")//Roboto, 15
            .position (x:35, y:149)
        Text("비밀번호")//Roboto, 15
            .position (x:28, y:192)
        Text("아이디/비밀번호찾기")
            .position(x:108, y:260)
        /*Button(action : Login)
         .position(x:272, y:148){
            //Text("로그인")
        }
        W
        */
        //.position(x:272, y:148)
        Text("회원가입")
            .position (x:150, y:300)
        
    }
}

*/
