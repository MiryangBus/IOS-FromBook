//
//  EmailConfirmView.swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/08.
//  보류임

import SwiftUI

struct EmailConfirmView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct EmailConfirmView_Previews: PreviewProvider {
    static var previews: some View {
        EmailConfirmView()
    }
}
