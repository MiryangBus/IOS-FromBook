//
//  SigninView.swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/08.
//사이즈 안맞아서 석나가서 일단 보류함



import SwiftUI

struct SigninView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SigninView_Previews: PreviewProvider {
    static var previews: some View {
        SigninView()
    }
}
