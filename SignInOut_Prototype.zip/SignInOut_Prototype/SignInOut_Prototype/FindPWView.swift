//
//  FindPWView.swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/09.
//

/*
 사이즈 왜 안맞음 피그마랑 으아아

import SwiftUI

struct FindInfoView : View{
    var body: some View{
        Text("생자대 생활 정보 톡")
            .position (x:107, y:58)
        Text("아이디찾기")//볼드, FFAD62
            .position (x:159, y:90)
        Text("비밀번호찾기")//일반, 검은색
            .position (x:35, y:149)
        Text("가입할 떄 입력하셨던 이메일을 입력해 주세요.")//Roboto, regular, 18
            .position (x:28, y:192)
        
        /*TextField 이메일입력란
            .position(x:50, y:217)
            W260 H26
        */
        /*Button(action : 아이디찾기 리퀘스트)
         .position(x:144, y:272){
            //Text("로그인")
            W73 H18
        }
        */
        
    }
}*/
