//
//  InfoData.swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/08.
// ######################################################################
// 회원정보 명세, 필요한 메서드, 함수, 서버 Request In/Out 등 이쪽에서 끌어올 계획이긴함
// ######################################################################
// 아직 확정 아님 이정도 밑그림 그림
import Foundation

//codable?
//###공부필요, 장단점, 적용여부 등 고민필요
// private 접근제어 어떻게?
struct StudentInfo{
    private var ID : String = "ProtoID" //ID
    private var PW : String = "ProtoPW"//PW
    private var StuName : String = "홍기일동"//이름
    private var StuNum : String = "000000000"//학번
    
    var Nick_Name : String = "히히닉네임이다52"//닉네임
    
    private var PNU_Email : String //본인확인용 Email
}




// 1. 회원가입 함수(구현예정)
// 리퀘스트 받아 struct정보 저장하는 형태로,
// 이후 저장되었는지 그런 부분, request받고 줄 때 오류 수정, 오류 시 대책 등이 필요해 보임


// 2. 회원탈퇴 함수(구현예정)
// 리퀘스트 보내 특정 정보 회원탈퇴 기능 구현 예정
// 이메일에 코드 받아서 진행, 탈퇴 시 원복 불가함 고지할 예정
// ##불의의 경우 발생 시 유예 두는 등의 조작 추가?(논의필요)

//3. Error Try-Catch 구현 필요
// 다양한 에러들?
// 예상되는 에러들 다 구현하고,
// Request 하면서 일어나는 에러들 해결
// 검증엔 시간이 걸리겠지
