//
//  SignInOut_PrototypeApp.swift
//  SignInOut_Prototype
//
//  Created by myspoon on 2023/01/08.
//

import SwiftUI

@main
struct SignInOutPrototypeApp : App{
    var body: some Scene{
        WindowGroup{
            HomeView()
        }
    }
}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
